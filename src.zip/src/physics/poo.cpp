#include "../ui.hpp"
#include "../main_loop.hpp"
#include "physics.hpp"

std::vector<uint32_t> cel_first_particle;
std::vector<uint32_t> cel_particle_ids;

int particle_count;
float cell_size;
float density_area;
float da2; // precalculation for density_area^2
float delta_time;
float particle_mass = 1.0f;
glm::vec3 gravity(0.0, -9.81, 0.0);
glm::ivec3 grid_size;

std::vector<glm::vec3> colors;
std::vector<glm::vec3> positions;

constexpr float REST_DENSITY = 0.0001f;
constexpr float TAIT_EXPONENT = 7.0f;
constexpr float TAIT_STIFFNESS = 2.0f;
constexpr float PARTICLE_SPACING = 0.01f;

// Pi = 3 btw

float Poly6Kernel(float r2){
    float diff = da2 - r2;

    if (diff <= 0.0f){
        return 0.0f;
    }

    return 315.0f / (64.0f * 3.0f * std::pow(density_area,9)) * diff * diff * diff;
}

float TaitEquation(float rest_density, float exponent, float stiffness, float density){
    return stiffness * rest_density / exponent * (std::pow(density / rest_density, exponent) - 1);
}

glm::vec3 SpikyGradient(const glm::vec3& r_vec, float r) {
    if (r <= 1e-6f || r >= density_area) {
        return glm::vec3(0.0f);
    }
    float diff = density_area - r;
    float coef = -45.0f / (3 * da2 * da2 * da2) * diff * diff / r;
    return r_vec * coef;
}

class Particle{
    private:

    protected:
    glm::vec3 position; // coordonate
    float m = 1.0f;

    Particle(float x, float y, float z): position(x, y, z){}

    public:


    glm::vec3 GetPosition(){
        return position;
    }

    void IncreasePosition(glm::vec3 inc){
        position += inc;
    }

    // Keeps the particle inside [eps, max - eps]. Also recovers from NaN/inf,
    // because a NaN position becomes a garbage grid index later on.
    void ClampToBox(const glm::vec3& max){
        const float eps = 1e-4f;

        if (!std::isfinite(position.x) || !std::isfinite(position.y) || !std::isfinite(position.z)){
            position = max * 0.5f;
        }

        position = glm::clamp(position, glm::vec3(eps), max - glm::vec3(eps));
    }

    float GetM(){
        return m;
    }

    void SetM(float m){
        this->m = m;
    }
};

class Liquid: public Particle{
    private:

    float radious;
    float density = 0.0f, presure = 0.0f;

    glm::vec3 force = glm::vec3(0.0f);

    public:

    Liquid(float x, float y, float z, float r): Particle(x, y, z), radious(r){}

    // A particle contributes to its own density too. This also guarantees density > 0,
    // so dividing by it later is safe.
    void ResetDensity(){
        density = m * Poly6Kernel(0.0f);
    }

    void UpdatePressure(){
        presure = TaitEquation(REST_DENSITY, TAIT_EXPONENT, TAIT_STIFFNESS, density);
    }

    void IncreaseDensity(float d){
        density += d;
    }

    float GetDensity(){
        return density;
    }

    void IncreaseForce(glm::vec3 f){
        force += f;
    }

    glm::vec3 GetForce(){
        return force;
    }

    void IncreasePreasure(float p){
        presure += p;
    }

    float GetPresure(){
        return presure;
    }

    void SetRadious(float r){
        radious = r;
    }

    float GetRadious(){
        return radious;
    }

    void ResetForce(){
        force = glm::vec3(0.0f);
    }
};

std::vector<Liquid> particles;

// Cell offsets that cover every unordered pair of neighbouring cells exactly once.
// There are 26 neighbours, half of them (13) are "forward", the other half are the
// same pairs seen from the other side. Forward = first non-zero component of (z, y, x)
// is positive. Note the mixed-sign ones, e.g. (1, -1, 0) or (1, 1, -1): those can't be
// reached by only using offsets in {0, 1}.
const glm::ivec3 FORWARD_OFFSETS[13] = {
    glm::ivec3( 1,  0,  0),
    glm::ivec3(-1,  1,  0), glm::ivec3(0,  1,  0), glm::ivec3(1,  1,  0),
    glm::ivec3(-1, -1,  1), glm::ivec3(0, -1,  1), glm::ivec3(1, -1,  1),
    glm::ivec3(-1,  0,  1), glm::ivec3(0,  0,  1), glm::ivec3(1,  0,  1),
    glm::ivec3(-1,  1,  1), glm::ivec3(0,  1,  1), glm::ivec3(1,  1,  1),
};

// Distance along one axis from pos (inside cell `cell`) to the neighbouring cell
// at `offset` (-1, 0 or 1).
float AxisGap(float pos, int cell, int offset){
    if (offset > 0){
        return std::max((cell + 1) * cell_size - pos, 0.0f);
    }
    if (offset < 0){
        return std::max(pos - cell * cell_size, 0.0f);
    }
    return 0.0f;
}

// Calls pair_func(a, b) once for every pair of particles that can be closer than
// density_area. Pairs that are farther apart can also show up (the kernels return 0
// for them), but a pair is never visited twice and never missed.
template <typename PairFunc>
void ForEachNeighborPair(PairFunc pair_func){
    for (int cz = 0; cz < grid_size.z; cz++){
        for (int cy = 0; cy < grid_size.y; cy++){
            for (int cx = 0; cx < grid_size.x; cx++){
                int cell = cz * grid_size.x * grid_size.y + cy * grid_size.x + cx;
                int cell_start = cel_first_particle[cell];
                int cell_end = cel_first_particle[cell + 1];

                for (int i = cell_start; i < cell_end; i++){
                    Liquid& a = particles[cel_particle_ids[i]];
                    glm::vec3 pos = a.GetPosition();

                    // same cell: only the particles after this one
                    for (int j = i + 1; j < cell_end; j++){
                        pair_func(a, particles[cel_particle_ids[j]]);
                    }

                    for (const glm::ivec3& offset : FORWARD_OFFSETS){
                        int nx = cx + offset.x;
                        int ny = cy + offset.y;
                        int nz = cz + offset.z;

                        // check every axis on its own, so x + 1 can't wrap into the next row
                        if (nx < 0 || nx >= grid_size.x ||
                            ny < 0 || ny >= grid_size.y ||
                            nz < 0 || nz >= grid_size.z){
                            continue;
                        }

                        // skip the whole cell if even its closest point is out of range
                        float gap_x = AxisGap(pos.x, cx, offset.x);
                        float gap_y = AxisGap(pos.y, cy, offset.y);
                        float gap_z = AxisGap(pos.z, cz, offset.z);

                        if (gap_x * gap_x + gap_y * gap_y + gap_z * gap_z >= da2){
                            continue;
                        }

                        int neighbor = nz * grid_size.x * grid_size.y + ny * grid_size.x + nx;

                        for (int j = cel_first_particle[neighbor]; j < cel_first_particle[neighbor + 1]; j++){
                            pair_func(a, particles[cel_particle_ids[j]]);
                        }
                    }
                }
            }
        }
    }
}

void DensityPair(Liquid& a, Liquid& b){
    glm::vec3 offset = b.GetPosition() - a.GetPosition();

    float density_impact = Poly6Kernel(glm::dot(offset, offset));

    a.IncreaseDensity(b.GetM() * density_impact);
    b.IncreaseDensity(a.GetM() * density_impact);
}

void ForcePair(Liquid& a, Liquid& b){
    glm::vec3 offset = b.GetPosition() - a.GetPosition();
    float range = glm::length(offset);

    if (range >= density_area){
        return;
    }

    // Symmetric pressure term: swapping a and b gives the exact opposite result, so the
    // visiting order doesn't matter and one evaluation serves both particles.
    float pressure_term = a.GetPresure() / (a.GetDensity() * a.GetDensity())
        + b.GetPresure() / (b.GetDensity() * b.GetDensity());

    glm::vec3 gradient = SpikyGradient(offset, range);

    a.IncreaseForce(b.GetM() * pressure_term * gradient);
    b.IncreaseForce(-a.GetM() * pressure_term * gradient);
}

class LiquidFactory{
    private:
    float last_x = PARTICLE_SPACING, last_y = PARTICLE_SPACING, last_z = PARTICLE_SPACING;
    float default_x, default_y, default_z;

    public:
    LiquidFactory(){}
    LiquidFactory(float x, float y, float z):default_x(x), default_y(y), default_z(z){}

    Liquid CreateLiquidParticleBegine(){
        if (last_x < grid_size.x * cell_size){
            last_x += PARTICLE_SPACING;
        }
        else if(last_y < grid_size.y * cell_size){
            last_x = PARTICLE_SPACING;
            last_y += PARTICLE_SPACING;
        }
        else if(last_z < grid_size.z * cell_size){
            last_x = PARTICLE_SPACING;
            last_y = PARTICLE_SPACING;
            last_z += PARTICLE_SPACING;
        }

        Liquid liquid(last_x, last_y, last_z, 1.0);
        liquid.SetM(particle_mass);
        return liquid;
    }

    Liquid CreateLiquidParticle(){
        Liquid liquid(default_x, default_y, default_z, 1.0);
        liquid.SetM(particle_mass);
        return liquid;
    }

    void SetX(float x){
        default_x = x;
    }

    void SetY(float y){
        default_y = y;
    }

    void SetZ(float z){
        default_z = z;
    }
};



LiquidFactory liquid_factory;

void UpdateGridSize(){
    grid_size = glm::max(glm::ivec3(g_ui.box_size / cell_size), glm::ivec3(1));

    liquid_factory.SetX(cell_size * grid_size.x / 2);
    liquid_factory.SetY(cell_size * grid_size.y * 3 / 4);
    liquid_factory.SetZ(cell_size * grid_size.z / 2);
}

void BuildGrid(){
    positions.resize(particles.size());

    for (size_t i = 0; i < particles.size(); i++){
        positions[i] = particles[i].GetPosition();
    }

    std::tie(cel_first_particle, cel_particle_ids) =
        GenerateGrid(positions, grid_size, 1.0f / cell_size);
}

void ComputeDensities(){
    for (Liquid& particle : particles){
        particle.ResetDensity();
    }

    ForEachNeighborPair(DensityPair);
}

void ComputePressures(){
    for (Liquid& particle : particles){
        particle.UpdatePressure();
    }
}

void ComputeForces(){
    ForEachNeighborPair(ForcePair);
}

void Integrate(){
    for (Liquid& particle : particles){
        particle.IncreaseForce(gravity);
        particle.IncreasePosition(particle.GetForce() * delta_time);
        particle.ClampToBox(g_ui.box_size);
        particle.ResetForce();
    }
}

void PhysicsUpdate(){
    // grid_size has to be up to date before the grid is built
    UpdateGridSize();
    BuildGrid();

    ComputeDensities();
    ComputePressures();
    ComputeForces();

    Integrate();
}

std::span<glm::vec3> PhysicsGetPositions(){
    positions.resize(particles.size());

    for(size_t i = 0; i < particles.size(); i++){
        positions[i] = particles[i].GetPosition();
    }

    return std::span(positions);
}

void PhysicsInit(){
    delta_time = FIXED_TIMESTEP;
    cell_size = g_ui.grid_cell_size;
    density_area = cell_size; //wip
    da2 = density_area * density_area;
    particle_count = 100;

    // mass of one cube of fluid at rest density, so the starting lattice is at rest density
    particle_mass = REST_DENSITY * PARTICLE_SPACING * PARTICLE_SPACING * PARTICLE_SPACING;

    UpdateGridSize();

    liquid_factory = LiquidFactory(cell_size * grid_size.x / 2, cell_size * grid_size.y * 3 / 4, cell_size * grid_size.z / 2);

    // PhysicsInit is also called on reset, so drop the old particles first
    particles.clear();
    particles.reserve(particle_count);

    for(int i = 0; i < particle_count; i++){
        particles.push_back(liquid_factory.CreateLiquidParticleBegine());
    }

    positions.resize(particles.size());
}

void IncreaseParticles(){
    particles.push_back(liquid_factory.CreateLiquidParticle());
    particle_count = int(particles.size());
}

void DecreaseParticles(){
    if (particles.empty()){
        return;
    }

    particles.pop_back();
    particle_count = int(particles.size());
}

std::span<glm::vec3> Colors(){
    colors.resize(particles.size());

    for (size_t i = 0; i < particles.size(); i++){
        colors[i] = glm::vec3(1.0f);
    }

    return std::span(colors);
}